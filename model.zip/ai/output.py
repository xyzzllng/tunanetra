"""Short spoken answers; full detector/OCR data stays in API metadata."""
import os
import re


def spoken_text(text, max_words=None):
    """Read OCR verbatim up to a word boundary; do not invent a summary."""
    limit = max(10, int(max_words or os.getenv('OCR_SPOKEN_MAX_WORDS', '100')))
    words = str(text or '').split()
    if len(words) <= limit:
        return str(text or '').strip()
    excerpt = ' '.join(words[:limit]).rstrip('.,;:')
    return excerpt + '. Masih ada lanjutan teks.'


def concise_answer(text, max_words=70):
    """Remove generated score commentary, not percentages printed in OCR."""
    text = str(text or '').strip()
    text = re.sub(r'(?i)\s*\(?\b(?:dengan\s+)?(?:confidence|probability|probabilitas|skor model|skor area|tingkat keyakinan)\s*[:=]?\s*\d+(?:[.,]\d+)?\s*(?:%|persen)?\)?', '', text)
    text = re.sub(r'(?i)\b\d+(?:[.,]\d+)?\s*(?:%|persen)\s*(?:yakin|keyakinan)\b', '', text)
    text = re.sub(r'(?im)^\s*(?:[-*#]+|\d+\))\s+', '', text).replace('**', '')
    text = re.sub(r'(?i)^(?:saya berhasil membaca teks berikut|teks terbaca|tulisan di depan adalah)\s*:\s*', '', text)
    sentences = re.split(r'(?<=[.!?])\s+', text)
    seen, output = set(), []
    for sentence in sentences:
        key = ' '.join(sentence.casefold().split())
        if key and key not in seen:
            seen.add(key)
            output.append(sentence.strip())
    return spoken_text(' '.join(output), max_words=max_words)
